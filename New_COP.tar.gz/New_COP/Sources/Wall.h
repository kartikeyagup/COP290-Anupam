#include <bits/stdc++.h>

using namespace std;

class Wall
{
	private:

		string Type;
		string ID;
		Vector Position;



}