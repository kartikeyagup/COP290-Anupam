#ifndef TESTVECTOR_H
#define TESTVECTOR_H

#include <bits/stdc++.h>
#include "Vector.h"

class TestVector
{
	public :
		bool TestAddVector(Vector , Vector);
		bool TestSubVector(Vector , Vector);
};

#endif