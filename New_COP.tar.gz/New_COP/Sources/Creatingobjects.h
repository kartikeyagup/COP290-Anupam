#ifndef CREATINGOBJECTS_H
#define CREATINGOBJECTS_H
#include <bits/stdc++.h>
#include "Graphicsrendering.h"
#include "Tank.h"


void createface(Face);
// void createbullet(std::vector<Face>,Bullet);
// void createmissile(std::vector<Face>,Missile);
void createtank(std::vector<Face>,Tank);
// void createwall(std::vector<Face>);
// void createeagle(std::vector<Face>);
#endif